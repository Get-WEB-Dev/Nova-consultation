"use client";
import { useEffect, useState } from "react";
import { getUser } from "@/lib/supabase/auth";
import {
  Clock,
  Save,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Info,
} from "lucide-react";

const NAV_BG = "#003580";
const ACCENT = "#0071c2";
const SKY = "#38bdf8";

const DAYS = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];
const ABBR: Record<string, string> = {
  Monday: "Mon",
  Tuesday: "Tue",
  Wednesday: "Wed",
  Thursday: "Thu",
  Friday: "Fri",
  Saturday: "Sat",
  Sunday: "Sun",
};
const HOURS = Array.from({ length: 24 }, (_, i) => ({
  value: `${i.toString().padStart(2, "0")}:00`,
  label:
    i === 0
      ? "12:00 AM"
      : i < 12
        ? `${i}:00 AM`
        : i === 12
          ? "12:00 PM"
          : `${i - 12}:00 PM`,
}));

interface DaySchedule {
  enabled: boolean;
  start: string;
  end: string;
}

const DEFAULT: Record<string, DaySchedule> = {
  Monday: { enabled: true, start: "09:00", end: "17:00" },
  Tuesday: { enabled: true, start: "09:00", end: "17:00" },
  Wednesday: { enabled: true, start: "09:00", end: "17:00" },
  Thursday: { enabled: true, start: "09:00", end: "17:00" },
  Friday: { enabled: true, start: "09:00", end: "17:00" },
  Saturday: { enabled: false, start: "10:00", end: "14:00" },
  Sunday: { enabled: false, start: "10:00", end: "14:00" },
};

export default function SchedulePage() {
  const [schedule, setSchedule] = useState(DEFAULT);
  const [duration, setDuration] = useState(15);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    const u = getUser();
    if (!u) return;
    fetch(`/api/doctor/profile?doctorId=${u.id}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.data?.consultation_duration_mins)
          setDuration(j.data.consultation_duration_mins);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    const u = getUser();
    if (!u) return;
    setSaving(true);
    setMsg(null);
    try {
      await fetch("/api/doctor/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          doctorId: u.id,
          consultation_duration_mins: duration,
        }),
      });
      setMsg({ ok: true, text: "Schedule saved!" });
    } catch {
      setMsg({ ok: false, text: "Failed to save." });
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 3000);
    }
  };

  const enabledDays = Object.values(schedule).filter((d) => d.enabled).length;
  const totalHours = Object.entries(schedule)
    .filter(([, d]) => d.enabled)
    .reduce(
      (s, [, d]) => s + Math.max(0, parseInt(d.end) - parseInt(d.start)),
      0,
    );

  if (loading)
    return (
      <div className="space-y-4 max-w-2xl">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-16 bg-white rounded-2xl animate-pulse border border-slate-200"
          />
        ))}
      </div>
    );

  return (
    <div className="space-y-5 max-w-2xl">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="font-extrabold text-slate-900 text-[18px]">
            My Schedule
          </h1>
          <p className="text-[12px] text-slate-400 mt-0.5">
            Set your weekly availability
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-[13px] font-extrabold text-white transition-all active:scale-95 disabled:opacity-60"
          style={{ background: NAV_BG }}
        >
          {saving ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Save className="w-4 h-4" />
          )}{" "}
          Save
        </button>
      </div>

      {/* Toast */}
      {msg && (
        <div
          className={`flex items-center gap-2 p-3.5 rounded-xl text-[13px] font-semibold border ${msg.ok ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-rose-50 text-rose-700 border-rose-200"}`}
        >
          {msg.ok ? (
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
          )}
          {msg.text}
        </div>
      )}

      {/* Summary chips */}
      <div className="flex flex-wrap gap-2">
        {[
          { label: `${enabledDays} days/week`, color: ACCENT, bg: "#eff6ff" },
          { label: `${duration}min sessions`, color: "#b45309", bg: "#fffbeb" },
          { label: `${totalHours}h/week`, color: "#15803d", bg: "#f0fdf4" },
        ].map(({ label, color, bg }) => (
          <div
            key={label}
            className="flex items-center gap-1.5 text-[11px] font-bold px-3 py-1.5 rounded-full"
            style={{ background: bg, color }}
          >
            {label}
          </div>
        ))}
      </div>

      {/* Session duration */}
      <div
        className="bg-white border border-slate-200 rounded-2xl p-5"
        style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}
      >
        <h2 className="text-[13px] font-extrabold text-slate-800 mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4" style={{ color: ACCENT }} /> Session
          Duration
        </h2>
        <div className="flex flex-wrap gap-2">
          {[10, 15, 20, 30, 45, 60].map((m) => (
            <button
              key={m}
              onClick={() => setDuration(m)}
              className="px-4 py-2 rounded-xl text-[13px] font-bold transition-all active:scale-95"
              style={
                duration === m
                  ? { background: NAV_BG, color: "white" }
                  : {
                      background: "#f8fafc",
                      color: "#475569",
                      border: "1px solid #e2e8f0",
                    }
              }
            >
              {m} min
            </button>
          ))}
        </div>
        <p className="text-[11px] text-slate-400 mt-3 flex items-center gap-1">
          <Info className="w-3 h-3" /> Patients see this when viewing your
          profile.
        </p>
      </div>

      {/* Weekly schedule */}
      <div
        className="bg-white border border-slate-200 rounded-2xl overflow-hidden"
        style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}
      >
        <div
          className="px-5 py-3.5 border-b border-slate-100 flex items-center gap-2"
          style={{ background: "#f8fafc" }}
        >
          <Calendar className="w-4 h-4" style={{ color: ACCENT }} />
          <h2 className="text-[13px] font-extrabold text-slate-800">
            Weekly Availability
          </h2>
        </div>
        <div className="divide-y divide-slate-50">
          {DAYS.map((day) => {
            const d = schedule[day];
            return (
              <div
                key={day}
                className={`flex items-center gap-3 px-4 py-3.5 transition-colors ${d.enabled ? "" : "opacity-55"}`}
              >
                {/* Toggle */}
                <button
                  onClick={() =>
                    setSchedule((prev) => ({
                      ...prev,
                      [day]: { ...prev[day], enabled: !prev[day].enabled },
                    }))
                  }
                  className="relative flex-shrink-0 rounded-full transition-all focus:outline-none"
                  style={{
                    width: 40,
                    height: 22,
                    background: d.enabled ? NAV_BG : "#cbd5e1",
                  }}
                >
                  <span
                    className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${d.enabled ? "left-5" : "left-0.5"}`}
                  />
                </button>

                <p
                  className={`w-24 flex-shrink-0 text-[13px] font-bold ${d.enabled ? "text-slate-900" : "text-slate-400"}`}
                >
                  {day}
                </p>

                {d.enabled ? (
                  <div className="flex items-center gap-2 flex-1 flex-wrap">
                    <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
                      <Clock className="w-3 h-3 text-slate-400 flex-shrink-0" />
                      <select
                        value={d.start}
                        onChange={(e) =>
                          setSchedule((prev) => ({
                            ...prev,
                            [day]: { ...prev[day], start: e.target.value },
                          }))
                        }
                        className="bg-transparent text-[12px] text-slate-700 outline-none cursor-pointer"
                      >
                        {HOURS.map((h) => (
                          <option key={h.value} value={h.value}>
                            {h.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <span className="text-slate-400 text-[11px]">→</span>
                    <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
                      <Clock className="w-3 h-3 text-slate-400 flex-shrink-0" />
                      <select
                        value={d.end}
                        onChange={(e) =>
                          setSchedule((prev) => ({
                            ...prev,
                            [day]: { ...prev[day], end: e.target.value },
                          }))
                        }
                        className="bg-transparent text-[12px] text-slate-700 outline-none cursor-pointer"
                      >
                        {HOURS.map((h) => (
                          <option key={h.value} value={h.value}>
                            {h.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <span className="text-[11px] text-slate-400 hidden sm:block">
                      {Math.max(0, parseInt(d.end) - parseInt(d.start))}h
                    </span>
                  </div>
                ) : (
                  <p className="text-[12px] text-slate-400 italic flex-1">
                    Day off
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Week overview visual */}
      <div
        className="bg-white border border-slate-200 rounded-2xl p-5"
        style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}
      >
        <h2 className="text-[13px] font-extrabold text-slate-800 mb-4 flex items-center gap-2">
          <Calendar className="w-4 h-4" style={{ color: ACCENT }} /> Week
          Overview
        </h2>
        <div className="grid grid-cols-7 gap-1.5">
          {DAYS.map((day) => {
            const d = schedule[day];
            const h = d.enabled
              ? Math.max(0, parseInt(d.end) - parseInt(d.start))
              : 0;
            return (
              <div key={day} className="text-center">
                <p className="text-[10px] font-extrabold text-slate-400 mb-1.5 uppercase">
                  {ABBR[day]}
                </p>
                <div
                  className="h-16 rounded-xl flex flex-col items-center justify-center text-[11px] font-bold transition-all"
                  style={
                    d.enabled
                      ? { background: NAV_BG, color: "white" }
                      : { background: "#f1f5f9", color: "#94a3b8" }
                  }
                >
                  {d.enabled ? (
                    <>
                      <span>{h}h</span>
                      <span className="text-[9px] opacity-60 mt-0.5">
                        {d.start.split(":")[0]}-{d.end.split(":")[0]}
                      </span>
                    </>
                  ) : (
                    <span className="text-[10px]">Off</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
