"use client";
import { useState } from "react";
import Link from "next/link";
import {
  GitFork,
  Clock,
  Calendar,
  ChevronRight,
  FileText,
  Video,
  AlertCircle,
  X,
  MessageSquare,
} from "lucide-react";

const NAV_BG = "#003580";
const ACCENT = "#0071c2";
const SKY = "#38bdf8";

interface FU {
  id: string;
  name: string;
  email: string;
  scheduledAt: string;
  symptoms: string;
  notes: string | null;
  summary: string | null;
  duration: number | null;
  createdAt: string;
  chat: { from: string; text: string; time: string }[];
}

const DATA: FU[] = [
  {
    id: "fu1",
    name: "Hana Tadesse",
    email: "hana@example.com",
    scheduledAt: new Date(Date.now() + 2 * 3600000).toISOString(),
    symptoms: "Fever follow-up — checking antibiotic response",
    notes: "Started amoxicillin 500mg. Check if fever has subsided.",
    summary:
      "Initial consultation for fever. Prescribed antibiotics. Follow-up in 3 days.",
    duration: 8,
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    chat: [
      {
        from: "patient",
        text: "Doctor, my fever is at 38.5°C",
        time: "3 days ago",
      },
      {
        from: "doctor",
        text: "Please start the antibiotic course and rest well. Come back in 3 days.",
        time: "3 days ago",
      },
    ],
  },
  {
    id: "fu2",
    name: "Amir Bekele",
    email: "amir@example.com",
    scheduledAt: new Date(Date.now() + 86400000).toISOString(),
    symptoms: "Blood pressure check — hypertension management",
    notes: "BP was 148/95. Started Amlodipine 5mg.",
    summary: "Hypertension diagnosed. Lifestyle changes + medication started.",
    duration: 12,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    chat: [
      {
        from: "patient",
        text: "Is it normal to feel dizzy after starting the medication?",
        time: "5 days ago",
      },
      {
        from: "doctor",
        text: "Mild dizziness is common initially. If it persists, contact me.",
        time: "5 days ago",
      },
    ],
  },
  {
    id: "fu3",
    name: "Sara Muleta",
    email: "sara@example.com",
    scheduledAt: new Date(Date.now() + 3 * 86400000).toISOString(),
    symptoms: "Skin rash — allergy follow-up",
    notes: "Prescribed hydrocortisone cream. Check improvement.",
    summary: "Allergic dermatitis. Topical treatment prescribed.",
    duration: 6,
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    chat: [],
  },
];

function timeUntil(iso: string) {
  const ms = new Date(iso).getTime() - Date.now();
  if (ms < 0) return "Overdue";
  const h = Math.floor(ms / 3600000);
  if (h < 1) return `In ${Math.floor(ms / 60000)}m`;
  if (h < 24) return `In ${h}h`;
  return `In ${Math.floor(h / 24)}d`;
}

function Card({ f, onClick }: { f: FU; onClick: () => void }) {
  const past = new Date(f.scheduledAt) < new Date();
  const urgent =
    !past && new Date(f.scheduledAt).getTime() - Date.now() < 6 * 3600000;
  return (
    <button
      onClick={onClick}
      className="w-full bg-white border border-slate-200 rounded-2xl p-4 text-left hover:shadow-md hover:-translate-y-0.5 transition-all active:scale-[0.99] group"
      style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}
    >
      <div className="flex items-start gap-3">
        {/* Avatar */}
        <div
          className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 text-white font-extrabold text-base"
          style={{ background: past ? "#be123c" : urgent ? "#b45309" : NAV_BG }}
        >
          {f.name[0]}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-0.5">
            <p className="font-extrabold text-[14px] text-slate-900">
              {f.name}
            </p>
            <span
              className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full`}
              style={
                past
                  ? { background: "#fff1f2", color: "#be123c" }
                  : urgent
                    ? { background: "#fffbeb", color: "#b45309" }
                    : { background: "#eff6ff", color: ACCENT }
              }
            >
              {past ? "Overdue" : urgent ? "⚡ Soon" : "Scheduled"}
            </span>
          </div>
          <p className="text-[12px] text-slate-500 truncate">{f.symptoms}</p>
          <div className="flex items-center gap-3 mt-2 flex-wrap">
            <span className="flex items-center gap-1 text-[11px] text-slate-400">
              <Calendar className="w-3 h-3" />
              {new Date(f.scheduledAt).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
            <span
              className={`flex items-center gap-1 text-[11px] font-bold`}
              style={{ color: past ? "#be123c" : urgent ? "#b45309" : ACCENT }}
            >
              <Clock className="w-3 h-3" />
              {timeUntil(f.scheduledAt)}
            </span>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-colors flex-shrink-0 mt-1" />
      </div>
    </button>
  );
}

function DetailPanel({ f, onClose }: { f: FU; onClose: () => void }) {
  return (
    <>
      <div className="fixed inset-0 bg-black/40 z-50" onClick={onClose} />
      <div
        className="fixed inset-x-3 top-14 bottom-14 z-50 bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-w-lg mx-auto"
        style={{ boxShadow: "0 16px 48px rgba(0,0,0,0.2)" }}
      >
        {/* Header */}
        <div
          className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100 flex-shrink-0"
          style={{ background: NAV_BG }}
        >
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-white font-extrabold flex-shrink-0"
            style={{ background: ACCENT }}
          >
            {f.name[0]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-extrabold text-white text-[14px] leading-tight">
              {f.name}
            </p>
            <p
              className="text-[11px]"
              style={{ color: "rgba(255,255,255,0.6)" }}
            >
              {f.email}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div
          className="flex-1 overflow-y-auto p-4 space-y-4"
          style={{ background: "#f8fafc" }}
        >
          {/* Scheduled time */}
          <div
            className="flex items-center gap-3 p-3.5 rounded-xl border border-blue-100"
            style={{ background: "#eff6ff" }}
          >
            <Calendar
              className="w-5 h-5 flex-shrink-0"
              style={{ color: ACCENT }}
            />
            <div className="flex-1">
              <p className="font-bold text-[12px]" style={{ color: ACCENT }}>
                Follow-up Scheduled
              </p>
              <p className="text-[11px] text-slate-600 mt-0.5">
                {new Date(f.scheduledAt).toLocaleDateString("en-US", {
                  weekday: "short",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
            <span
              className="text-[11px] font-extrabold px-2.5 py-1 rounded-full bg-white"
              style={{ color: ACCENT }}
            >
              {timeUntil(f.scheduledAt)}
            </span>
          </div>

          {/* Symptoms */}
          <div>
            <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-2">
              Symptoms
            </p>
            <div className="flex items-start gap-2 p-3.5 rounded-xl border border-rose-100 bg-rose-50">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <p className="text-[13px] text-rose-700">{f.symptoms}</p>
            </div>
          </div>

          {/* Summary */}
          {f.summary && (
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-2">
                Previous Summary
              </p>
              <div className="p-3.5 rounded-xl bg-white border border-slate-200">
                <p className="text-[13px] text-slate-600 leading-relaxed">
                  {f.summary}
                </p>
              </div>
            </div>
          )}

          {/* Notes */}
          {f.notes && (
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-2">
                Doctor Notes
              </p>
              <div className="flex items-start gap-2 p-3.5 rounded-xl border border-amber-100 bg-amber-50">
                <FileText className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-[13px] text-amber-800 leading-relaxed">
                  {f.notes}
                </p>
              </div>
            </div>
          )}

          {/* Chat history */}
          {f.chat.length > 0 && (
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-2">
                Chat History
              </p>
              <div className="space-y-2">
                {f.chat.map((m, i) => (
                  <div
                    key={i}
                    className={`flex ${m.from === "doctor" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className="max-w-[80%] px-3 py-2.5 rounded-2xl text-[13px]"
                      style={
                        m.from === "doctor"
                          ? {
                              background: NAV_BG,
                              color: "white",
                              borderBottomRightRadius: 4,
                            }
                          : {
                              background: "white",
                              color: "#1e293b",
                              border: "1px solid #e2e8f0",
                              borderBottomLeftRadius: 4,
                            }
                      }
                    >
                      <p>{m.text}</p>
                      <p
                        className="text-[10px] mt-0.5"
                        style={{
                          color:
                            m.from === "doctor"
                              ? "rgba(255,255,255,0.5)"
                              : "#94a3b8",
                        }}
                      >
                        {m.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {f.duration && (
            <p className="flex items-center gap-2 text-[12px] text-slate-400">
              <Clock className="w-3.5 h-3.5" /> Previous consultation:{" "}
              {f.duration} minutes
            </p>
          )}
        </div>

        {/* Footer actions */}
        <div className="px-4 py-3.5 border-t border-slate-200 flex gap-2 flex-shrink-0 bg-white">
          <Link
            href="/doctor-dashboard/consult"
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[13px] font-extrabold text-white transition-all active:scale-95"
            style={{ background: NAV_BG }}
          >
            <Video className="w-4 h-4" /> Start Follow-up Call
          </Link>
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-[13px] font-semibold text-slate-600 border border-slate-200 bg-white hover:bg-slate-50 transition-colors active:scale-95"
          >
            Close
          </button>
        </div>
      </div>
    </>
  );
}

export default function FollowUpsPage() {
  const [sel, setSel] = useState<FU | null>(null);
  const upcoming = DATA.filter((f) => new Date(f.scheduledAt) > new Date());
  const overdue = DATA.filter((f) => new Date(f.scheduledAt) <= new Date());

  return (
    <div className="space-y-5 max-w-2xl">
      {/* Header */}
      <div>
        <h1 className="font-extrabold text-slate-900 text-[18px]">
          Follow Ups
        </h1>
        <p className="text-[12px] text-slate-400 mt-0.5">
          {DATA.length} scheduled · {overdue.length} overdue
        </p>
      </div>

      {/* Overdue */}
      {overdue.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "#fff1f2" }}
            >
              <AlertCircle className="w-3 h-3" style={{ color: "#be123c" }} />
            </div>
            <h2 className="font-extrabold text-[14px] text-slate-900">
              Overdue ({overdue.length})
            </h2>
          </div>
          <div className="space-y-2.5">
            {overdue.map((f) => (
              <Card key={f.id} f={f} onClick={() => setSel(f)} />
            ))}
          </div>
        </div>
      )}

      {/* Upcoming */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div
            className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: "#eff6ff" }}
          >
            <Calendar className="w-3 h-3" style={{ color: ACCENT }} />
          </div>
          <h2 className="font-extrabold text-[14px] text-slate-900">
            Upcoming ({upcoming.length})
          </h2>
        </div>
        {upcoming.length === 0 ? (
          <div
            className="text-center py-12 bg-white border border-slate-200 rounded-2xl"
            style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}
          >
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-3"
              style={{ background: "#eff6ff" }}
            >
              <GitFork className="w-5 h-5" style={{ color: ACCENT }} />
            </div>
            <p className="font-bold text-slate-600">No upcoming follow-ups</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {upcoming.map((f) => (
              <Card key={f.id} f={f} onClick={() => setSel(f)} />
            ))}
          </div>
        )}
      </div>

      {sel && <DetailPanel f={sel} onClose={() => setSel(null)} />}
    </div>
  );
}
